import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class SignUp extends JFrame {

    JLabel title =  new JLabel("Registration Form for Library App");
    JLabel name=   new JLabel("Full Name:");
    JLabel age= new JLabel("Age:");
    JLabel password=   new JLabel("Create Passowrd:");
    JLabel confirmPassword= new JLabel("Confirm Password:");
    JButton create;
    JButton clearButton = new JButton("Clear");
    JButton login= new JButton("Login");
    JPanel newUserPanel;
    JTextField nameTextField;
    JTextField ageTextField;
    JTextField passwordTextField;
    JTextField confirmpasswordTextField;
    JCheckBox admin;




    public SignUp() throws IOException {
        super("Registration");

        create = new JButton("Create");
        newUserPanel = new JPanel();
        nameTextField = new JTextField(15);
        ageTextField = new JTextField(15);
        passwordTextField = new JPasswordField(15);
        confirmpasswordTextField= new JPasswordField(15);
        admin= new JCheckBox("Librarian");


        setLocationAndSize();
        setLayoutManager();
        addComponentsToContainer();


        Writer writer;
        File check = new File("userPass.txt");
        if (!check.exists()) {
            try{
                File texting = new File("userPass.txt");
                writer = new BufferedWriter(new FileWriter(texting));
                writer.write("message");
            }catch(IOException e){
                e.printStackTrace();
            }
        }else{
            check = new File("adminPass.txt");
            if (!check.exists()) {
                try{
                    File texting = new File("adminPass.txt");
                    writer = new BufferedWriter(new FileWriter(texting));
                    writer.write("message");
                }catch(IOException e){
                    e.printStackTrace();
                }
            }}
        //Checks if the file exists. will not add anything if the file does exist.


        create.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Library library = Library.getLibrary();
                try {
                    if(admin.isSelected()) {
                        String[] name = nameTextField.getText().split(" ");
                        String fname = name[0];
                        String lname = name[1];
                        String username = fname+" "+lname;
                        String password = passwordTextField.getText();
                        library.getLibrarians().add(new Librarian(lname,fname,username,password));
                        //new LibraryManager().saveAllData();
                        LibraryManager.getManager().saveAllData();
                    }else{
                        String[] name = nameTextField.getText().split(" ");
                        String fname = name[0];
                        String lname = name[1];
                        int age = Integer.parseInt(ageTextField.getText());
                        String username = fname+" "+lname;
                        String password = passwordTextField.getText();
                        library.getStudents().add(new Student(lname,fname,age,username,password));
                        LibraryManager.getManager().saveAllData();
                        //new LibraryManager().saveAllData();
                    }
                    TypeFile();
                } catch (IOException d) {
                    d.printStackTrace();
                }catch (NumberFormatException nfe){
                    JOptionPane.showMessageDialog(null, "Enter your age please.");
                }

            }
        });
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                nameTextField.setText("");
                passwordTextField.setText("");
                ageTextField.setText("");
                confirmpasswordTextField.setText("");

            }
        });

        login.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                try {
                    dispose();
                    Login log = new Login();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        admin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if (admin.isSelected()) {
                    age.setVisible(false);
                    ageTextField.setVisible(false);
                    age.setEnabled(false);
                }
                else{
                    age.setVisible(true);
                    ageTextField.setVisible(true);
                    age.setEnabled(true);

                }

            }
        });
    }

    public void setLocationAndSize() {
        title.setBounds(100, 30, 400, 30);

        name.setBounds(80, 70, 200, 30);
        age.setBounds(347, 74, 200, 30);

        password.setBounds(80, 110, 200, 30);
        confirmPassword.setBounds(80,150,200,30);
        nameTextField.setBounds(190,72,150,26);
        ageTextField.setBounds(375,77,29,25);

        passwordTextField.setBounds(189,118,150,20);
        confirmpasswordTextField.setBounds(190,156,150,20);
        admin.setBounds(195, 180,  95, 30);
        clearButton.setBounds(190, 230, 100, 30);
        create.setBounds(300, 230, 100, 30);
        login.setBounds(409,230,100,30);

    }

    public void setLayoutManager() {
        setSize(641,412);
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        newUserPanel.setLayout (null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void addComponentsToContainer() {
        newUserPanel.add(create);
        newUserPanel.add(nameTextField);
        newUserPanel.add(passwordTextField);
        newUserPanel.add(title);
        newUserPanel.add(name);
        newUserPanel.add(age);
        newUserPanel.add(ageTextField);
        newUserPanel.add(confirmPassword);
        newUserPanel.add(confirmpasswordTextField);
        newUserPanel.add(admin);
        newUserPanel.add(password);
        newUserPanel.add(clearButton);
        newUserPanel.add(login);
        getContentPane().add(newUserPanel);
    }

    public void TypeFile () throws IOException {
        if (admin.isSelected()) {
            File file = new File("adminPass.txt");
            Scanner scan = new Scanner(file);
            FileWriter filewrite = new FileWriter(file, true);
            String userText = " ";
            String passText = " ";
            String studName = nameTextField.getText();
            String studPass = passwordTextField.getText();
            String conPass = confirmpasswordTextField.getText();

            while (scan.hasNext()) {
                userText = scan.nextLine();
                passText = scan.nextLine();
            }
            if (studPass.equals(conPass)) {
                if (studName.equals(userText) && studPass.equals(passText)) {
                    JOptionPane.showMessageDialog(null, "Username is already in use");
                    nameTextField.setText("");
                    passwordTextField.setText("");
                    nameTextField.requestFocus();
                } else if (studName.equals("") && studPass.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please insert Username and Password");
                } else if (studName.length()<5 || studPass.length()<5){
                    JOptionPane.showMessageDialog(null, "Password too short or Please enter full name.");
                }else {
                    filewrite.write(studName + "\r\n" + studPass + "\r\n");
                    filewrite.close();
                    JOptionPane.showMessageDialog(null, "Account has been created.");
                    dispose();
                    Login login = new Login();
                }
            } else {
                JOptionPane.showMessageDialog(create, "Password Does Not Match");
            }
        } else {
            File file = new File("userPass.txt");
            Scanner scan = new Scanner(file);
            FileWriter filewrite = new FileWriter(file, true);
            String userText = " ";
            String passText = " ";
            int studAge= Integer.parseInt(ageTextField.getText());
            String studName = nameTextField.getText();
            String studPass = passwordTextField.getText();
            String conPass = confirmpasswordTextField.getText();
            while (scan.hasNext()) {
                userText = scan.nextLine();
                passText = scan.nextLine();
            }
            if (studPass.equals(conPass)) {
                if (studName.equals(userText) && studPass.equals(passText)) {
                    JOptionPane.showMessageDialog(null, "Username is already in use");
                    nameTextField.setText("");
                    passwordTextField.setText("");
                    nameTextField.requestFocus();
                } else if (studName.equals("") && studPass.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please insert Username and Password");
                }else if (studName.length()<5 || studPass.length()<5){
                    JOptionPane.showMessageDialog(null, "Password too short or Please enter full name.");
                }

                else {
                    filewrite.write(studName + "\r\n" + studPass + "\r\n");
                    filewrite.close();
                    JOptionPane.showMessageDialog(null, "Account has been created.");
                    dispose();
                    Login login = new Login();
                }
            } else {
                JOptionPane.showMessageDialog(create, "Password Does Not Match");
            }
        }
    }
}