import java.util.Comparator;

public class sortByID implements Comparator<Student> {
    @Override
    public int compare(Student s1, Student s2) {
        return s1.getStudID()-s2.getStudID();
    }
}
