import java.util.ArrayList;

public class Library {
    private ArrayList<Student> students;
    private ArrayList<Book> books;
    private ArrayList<Librarian> librarians;
    private static Library library;

    //Singleton Implementation
    private Library(){
        students = new ArrayList<Student>();
        books = new ArrayList<Book>();
        librarians = new ArrayList<Librarian>();
    }
    public static Library getLibrary(){
        if(library==null)
            library = new Library();
        return library;
    }
    //Singleton Implementation

    public ArrayList<Book> getBooks(){return books;}
    public ArrayList<Student> getStudents(){return students;}
    public ArrayList<Librarian> getLibrarians(){return librarians;}

    public Book getBook(String title){
        Book book=null;
        for(Book bk: books)
            if(bk.getTitle().equals(title))
                book = bk;
        return book;
    }

    public void addBook(String title, String authorName){
        getBooks().add(new Book(title,authorName));
    }
//    public void addStudent(String lname, String fname, int age, String uName, String pass){
//        getStudents().add(new Student(lname, fname, age, uName, pass));
//    }

    public void printBooks(){
        for(Book bk: books)
            System.out.println(bk.getAuthor());
    }

//    public void addNewBook(LibraryManager libMan){
//        libMan.createBook();
//
//    }

    public Book searchBook(String author, String title){
        Book bk = null;
        author = author.toUpperCase();
        title = title.toUpperCase();
        for(Book book: getBooks())
            if(book.getAuthor().toUpperCase().equals(author)&&book.getTitle().toUpperCase().equals(title))
                bk=book;
        return bk;

    }

    public Student findStudent(String username){
        username = username.toUpperCase();
        Student student = null;
        for(Student stud: getStudents())
            if(stud.getUserName().toUpperCase().equals(username))
                student = stud;
        return student;
    }

    public Librarian findLibrarian(String username){
        username = username.toUpperCase();
        Librarian librarian = null;
        for(Librarian lib: getLibrarians())
            if(lib.getUserName().toUpperCase().equals(username))
                librarian=lib;
        return librarian;
    }

    public void selfRemoveAccount(Account user){
        if(user instanceof Student) {
            for (Book bk : ((Student) user).getBorrowedBooks())
                bk.setNotBorrowed();//returns all books to library before deleting student
            getStudents().remove(user);
        }else
            getLibrarians().remove(user);

    }
}
