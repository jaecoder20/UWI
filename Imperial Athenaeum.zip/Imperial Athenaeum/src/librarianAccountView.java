/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;


public class librarianAccountView extends javax.swing.JFrame {

    public librarianAccountView(Librarian librarian, librarianGui libGui) {
        initComponents();
        this.librarian=librarian;
        this.libGui=libGui;
        setVisible(true);
        unameTxt.setText(librarian.getUserName());
        libGui.setVisible(false);
        accountView=this;
        pwTxt.setText(censorPass(librarian.getPassword()));

    }
    private String censorPass(String pass){
        //Censors Password
        int passwordLen = pass.length();
        int censorLettersAmt = (int) (passwordLen*.75);//determines the amount of letters to replace with '*' in the password (75%)
        String censoredPw=pass;
        for(int i=0;i<censorLettersAmt;i++)
            censoredPw=censoredPw.replace(censoredPw.charAt(i), '*');
        //pwTxt.setText(censoredPw);
        //Censors Password
        return censoredPw;

    }
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        accountDetails = new javax.swing.JLabel();
        userNameLabel = new javax.swing.JLabel();
        passLabel = new javax.swing.JLabel();
        unameTxt = new javax.swing.JLabel();
        pwTxt = new javax.swing.JLabel();
        logout = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        changePW = new javax.swing.JLabel();
        old = new javax.swing.JLabel();
        oldTxt = new javax.swing.JTextField();
        newLabel = new javax.swing.JLabel();
        newTxt = new javax.swing.JTextField();
        confirm = new javax.swing.JLabel();
        confirmTxt = new javax.swing.JTextField();
        changePass = new javax.swing.JButton();
        deleteAcc = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        accountDetails.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        accountDetails.setText("Account Details");

        userNameLabel.setText("Username:");

        passLabel.setText("Password:");

        unameTxt.setText("uname");

        pwTxt.setText("pw");

        logout.setText("Log Out");

        logout.addActionListener(new logOutListener());
        changePass.addActionListener(new changePassListener());
        backButton.addActionListener(new backButtonListener());
        deleteAcc.addActionListener(new deleteAccButton());

        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_left_32px.png"))); // NOI18N
        backButton.setMaximumSize(new java.awt.Dimension(38, 30));
        backButton.setMinimumSize(new java.awt.Dimension(38, 30));
        backButton.setPreferredSize(new java.awt.Dimension(38, 20));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(accountDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                                .addContainerGap()
                                                                .addComponent(userNameLabel)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(unameTxt))
                                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                                .addGap(14, 14, 14)
                                                                .addComponent(logout)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(passLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(pwTxt)))
                                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(accountDetails)
                                .addGap(35, 35, 35)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(userNameLabel)
                                        .addComponent(unameTxt))
                                .addGap(31, 31, 31)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(passLabel)
                                        .addComponent(pwTxt))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(backButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                                .addContainerGap())
        );

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_user_100px.png"))); // NOI18N

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        changePW.setFont(new java.awt.Font("Segoe UI Emoji", 1, 12)); // NOI18N
        changePW.setText("Change Password");

        old.setText("Old:");

        newLabel.setText("New: ");


        confirm.setText("Confirm:");

        changePass.setText("Change Password");
        deleteAcc.setBackground(new java.awt.Color(255, 51, 0));
        deleteAcc.setText("Delete My Account");


        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(old)
                                        .addComponent(newLabel)
                                        .addComponent(confirm))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(oldTxt)
                                        .addComponent(newTxt)
                                        .addComponent(confirmTxt)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGap(8, 8, 8)
                                                .addComponent(changePass)
                                                .addGap(0, 38, Short.MAX_VALUE)))
                                .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(changePW)
                                .addGap(65, 65, 65))
                        .addComponent(deleteAcc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(changePW)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(old)
                                        .addComponent(oldTxt))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(newLabel)
                                        .addComponent(newTxt))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(confirm)
                                        .addComponent(confirmTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(changePass)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                                .addComponent(deleteAcc))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();

        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
    }




    private class logOutListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null,"See you again soon "+ unameTxt.getText());
            accountView.setVisible(false);
            LibraryManager.getManager().saveAllData();
            try {
                new Login();
                LibraryManager.getManager().rewritePassFiles();
            } catch (IOException ex) {
            }

        }
    }
    private class changePassListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String old = oldTxt.getText();
            String newPass = newTxt.getText();
            String confirm = confirmTxt.getText();
            JOptionPane.showMessageDialog(null,changePassValidation(old,newPass,confirm));
            LibraryManager.getManager().saveAllData();
            LibraryManager.getManager().rewritePassFiles();//updates admin data in adminPass file

        }
    }
    private class backButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            accountView.setVisible(false);
            libGui.setVisible(true);
        }
    }
    private class deleteAccButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            int selection = JOptionPane.showConfirmDialog(null,"Are you sure you want to delete your account?");
            if(selection==0) {
                Library.getLibrary().selfRemoveAccount(librarian);//deletes student account
                LibraryManager.getManager().saveAllData();
                LibraryManager.getManager().rewritePassFiles();
                JOptionPane.showMessageDialog(null,"Goodbye "+unameTxt.getText());
                setVisible(false);
                libGui.setVisible(false);
                try {
                    new Login();
                } catch (IOException ex) {
                }
            }
            //JOptionPane.showConfirmDialog(null,"Are you sure you want to delete your account?");
        }
    }

    private String changePassValidation(String old, String newPass, String confirmPass){
        String message = "";
        if(!old.equals(librarian.getPassword())) {
            message = "Please enter your last password.";
            oldTxt.setText("");
            newTxt.setText("");
            confirmTxt.setText("");
        }
        else {
            if (!newPass.equals(confirmPass)) {
                message = "Passwords do not match";
            } else {
                message = "Password successfully changed.";
                oldTxt.setText("");
                newTxt.setText("");
                confirmTxt.setText("");
                Library.getLibrary().findLibrarian(librarian.getUserName()).setPassword(newPass);
                pwTxt.setText(censorPass(newPass));
                accountView.setVisible(true);

            }
        }
        return message;


    }

    // Variables declaration - do not modify
    private javax.swing.JLabel accountDetails;
    private javax.swing.JButton backButton;
    private javax.swing.JLabel changePW;
    private javax.swing.JButton changePass;
    private javax.swing.JLabel confirm;
    private javax.swing.JTextField confirmTxt;
    private javax.swing.JButton deleteAcc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton logout;
    private javax.swing.JLabel newLabel;
    private javax.swing.JTextField newTxt;
    private javax.swing.JLabel old;
    private javax.swing.JTextField oldTxt;
    private javax.swing.JLabel passLabel;
    private javax.swing.JLabel pwTxt;
    private javax.swing.JLabel unameTxt;
    private javax.swing.JLabel userNameLabel;
    private Librarian librarian;
    private librarianGui libGui;
    private librarianAccountView accountView;
    // End of variables declaration
}
