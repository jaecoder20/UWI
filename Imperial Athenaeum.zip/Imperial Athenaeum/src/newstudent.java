/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;


public class newstudent extends javax.swing.JFrame {


    public newstudent(librarianGui libGui) {
        super("New Student:");
        this.libGui=libGui;
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        setVisible(true);
    }
    public newstudent() {
        super("New Student:");
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        setVisible(true);
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        studentdetails = new javax.swing.JLabel();
        firstNameTxt = new javax.swing.JTextField();
        fname = new javax.swing.JLabel();
        lastNameTxt = new javax.swing.JTextField();
        lname = new javax.swing.JLabel();
        age = new javax.swing.JLabel();
        ageTxt = new javax.swing.JTextField();
        passwordTxt = new javax.swing.JPasswordField();
        pass = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        generatePWButton = new javax.swing.JButton();
        passwordTxt.setEditable(false);
        setDefaultCloseOperation(HIDE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        studentdetails.setFont(new java.awt.Font("Sitka Small", 0, 14)); // NOI18N
        studentdetails.setText("New Student Details");


        fname.setText("First Name:");

        lname.setText("Last Name:");

        age.setText("Age: ");


        pass.setText("Password:");

        submit.setText("Submit");

        cancel.setText("Cancel");

        cancel.addActionListener(new CancelButtonListener());
        submit.addActionListener(new SubmitButtonListener());
        generatePWButton.addActionListener(new generatePasswordButton());

        generatePWButton.setText("Generate Random Password");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(136, 136, 136)
                                                .addComponent(studentdetails))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addComponent(fname)
                                                .addGap(18, 18, 18)
                                                .addComponent(firstNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(lname)
                                                        .addComponent(age)
                                                        .addComponent(pass))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(passwordTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(generatePWButton))
                                                        .addComponent(lastNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(ageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(97, 97, 97)
                                                .addComponent(submit)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(cancel)))
                                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(studentdetails)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(fname, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(firstNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lastNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lname))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(age)
                                        .addComponent(ageTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(pass)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(passwordTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(generatePWButton)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(submit)
                                        .addComponent(cancel))
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }


    private class CancelButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }

    }
    private class SubmitButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Library library = Library.getLibrary();
            Student newStud = null;
            try {
                String fName = firstNameTxt.getText();
                String lName = lastNameTxt.getText();
                int age = Integer.parseInt(ageTxt.getText());
                String username = fName+" "+lName;
                String password = String.valueOf(passwordTxt.getPassword());
                if(fName.equals("")||username.equals("")||lName.equals("")||password.equals(""))
                    library = null;//set variable to null; triggers null pointer exception
                newStud = new Student(lName,fName,age,username,password);
                library.getStudents().add(newStud);
                libGui.showStudents();
                setVisible(false);
                JOptionPane.showMessageDialog(null, "Student Added");
                LibraryManager.getManager().saveAllData();
                LibraryManager.getManager().rewritePassFiles();


            }
            catch(NullPointerException npe){
                JOptionPane.showMessageDialog(null,"Please ensure all fields are filled.");
                //warninglabel1.setVisible(true);
                //if(warninglabel2.isVisible())
                    //warninglabel2.setVisible(false);
            }catch(NumberFormatException nfe){
                JOptionPane.showMessageDialog(null,"Enter a number for the age");
            }

        }
    }
    private class generatePasswordButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String upCase="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            String lowCase="abcdefghijklmnopqrstuvwxyz";
            String nums="0123456789";
            String special="!@#$%^&*()_+{}=-[];/?.,";
            String combo= upCase+lowCase+nums+special;
            Random number = new Random();
            int pwLength = 10;
            char[] password = new char[pwLength];
            for(int i=0;i<pwLength;i++)
                password[i]=combo.charAt(number.nextInt(combo.length()));
            passwordTxt.setText(new String(password));

        }

    }

    // Variables declaration - do not modify
    private javax.swing.JLabel age;
    private javax.swing.JTextField ageTxt;
    private javax.swing.JButton cancel;
    private javax.swing.JTextField firstNameTxt;
    private javax.swing.JLabel fname;
    private javax.swing.JButton generatePWButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField lastNameTxt;
    private javax.swing.JLabel lname;
    private javax.swing.JLabel pass;
    private javax.swing.JPasswordField passwordTxt;
    private javax.swing.JLabel studentdetails;
    private javax.swing.JButton submit;
    private librarianGui libGui;
    // End of variables declaration-
}
