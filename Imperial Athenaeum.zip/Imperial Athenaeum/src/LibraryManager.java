import java.io.*;
import java.util.Arrays;
import java.util.Formatter;
import java.util.Scanner;

public class LibraryManager {//Manages input and output to library data
    private Library library;
    private Scanner scanner;
    private PrintStream outputStream;
    private static LibraryManager manager;

    private LibraryManager() {
        library = Library.getLibrary();
        scanner = null;
        outputStream = null;

    }
    public static LibraryManager getManager(){
        if(manager==null)
            manager = new LibraryManager();
        return manager;
    }

//    public void createBook() {
//        try {
//            scanner = new Scanner(System.in);
//            System.out.println("Enter the title of the book");
//            String title = scanner.nextLine();
//            System.out.println("Enter the author of the book");
//            String author = scanner.nextLine();
//            library.addBook(title, author);
//        } catch (NumberFormatException nfe) {
//
//        }
//    }

    private void loadBooks(String bkFile) {
        scanner=null;
        Formatter created = null;
        try {
            File check = new File(bkFile);
            if(check.exists())
                scanner = new Scanner(new File(bkFile));
            else {
                created = new Formatter(bkFile);
                scanner = new Scanner(new File(bkFile));
            }
            while (scanner.hasNext()) {
                String[] dataLine = scanner.nextLine().split(":");
                String title = dataLine[0];
                String authorName = dataLine[1];
                library.addBook(title, authorName);
            }
            scanner.close();
        } catch (NumberFormatException nfe) {
        } catch (FileNotFoundException e) {
        }

    }

    private void loadStudents(String studFile){
        scanner=null;
        Formatter created = null;

        try{
            File check = new File(studFile);
            if(check.exists())
                scanner = new Scanner(new File(studFile));
            else {
                created = new Formatter(studFile);
                scanner = new Scanner(new File(studFile));
            }
            //scanner = new Scanner(new File(studFile));
            while (scanner.hasNext()){
                String[] dataLine = scanner.nextLine().split(":");
                String lName = dataLine[0];
                String fName = dataLine[1];
                int age = Integer.parseInt(dataLine[2]);
                String userName = dataLine[3];
                String password = dataLine[4];
                String[] booksBorrowed=null;
                Student stud = new Student(lName, fName, age, userName, password);
                if(dataLine.length>5) {
                    booksBorrowed = dataLine[5].split(" ");
                    //System.out.println(Arrays.toString(booksBorrowed));
                    String[] arrBookName = new String[100];
                    StringBuilder bookName = new StringBuilder();
                    for (int i = 0; i < booksBorrowed.length; i++) {
                        bookName = new StringBuilder();
                        arrBookName = booksBorrowed[i].split(";");
                        //System.out.println(Arrays.toString(arrBookName));
                        for (int g = 0; g < arrBookName.length; g++) {
                            bookName.append(" ").append(arrBookName[g]);
                        }
                        //System.out.println(String.valueOf(bookName.deleteCharAt(0)));
                        stud.addBorrowed(String.valueOf(bookName.deleteCharAt(0)));
                        //System.out.println(stud.searchBookByTitle(String.valueOf(bookName.deleteCharAt(0))).getTitle());
                    }
                }
                library.getStudents().add(stud);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File to read student data not found");
        }catch (NumberFormatException nfe){
            System.out.println("Incorrect input for loading student");
        }
    }

    private void saveStudents(String studFile) {
        try {
            outputStream = new PrintStream(new FileOutputStream(studFile));
            String output = "";
            String[] bkTitle;
            String bkName="";
            for (Student stud : library.getStudents()) {
                bkTitle = new String[100];
                output = stud.getLName() + ":" + stud.getFName() + ":" + stud.getAge() + ":"+stud.getUserName()+":"+stud.getPassword()+":";
                for (Book bk: stud.getBorrowedBooks()) {
                    bkName = "";
                    bkTitle = bk.getTitle().split(" ");
                    for(int i=0;i< bkTitle.length;i++){
                        if(i!= bkTitle.length-1)
                            bkName+=bkTitle[i]+";";
                        else
                            bkName+=bkTitle[i];
                    }
                    output+=bkName+" ";
                }
                outputStream.println(output);
            }
            outputStream.close();

        } catch (FileNotFoundException e) {
            System.out.println("File to save students not found");
        }catch (NullPointerException npe){}
    }
    public void createStudent(){
        try{
            scanner=new Scanner(System.in);
            System.out.println("Enter the last name of the student");
            String lName = scanner.nextLine();
            System.out.println("Enter the first name of the student");
            String fName = scanner.nextLine();
            System.out.println("Enter the age of the student");
            int age = Integer.parseInt(scanner.next());
            System.out.println("Enter the student's username");
            String userNme = scanner.nextLine();
            System.out.println("Enter password");
            String password = scanner.nextLine();
            library.getStudents().add(new Student(lName,fName,age,userNme,password));
        }catch(NumberFormatException nfe){
            System.out.println("Incorrect value given for creating student");
        }
    }

    private String getStudentsFile() {
        return "studentsData.txt";
    }

    private String getBooksFile() {
        return "booksData.txt";
    }
    private String getLibrariansFile() {
        return "librariansData.txt";
    }

    public void loadAllData() {
        loadBooks(getBooksFile());
        loadStudents(getStudentsFile());
        loadLibrarian(getLibrariansFile());
    }

    private void saveAllBooks(String bkFile) {//implements persistent storage for book data
        try {
            outputStream = new PrintStream(new FileOutputStream(bkFile));
            for (Book bk : library.getBooks())
                outputStream.println(bk.getTitle() + ":" + bk.getAuthor());
            outputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("File to save book data not found");
        }
    }

    public void saveAllData() {

        saveAllBooks(getBooksFile());
        saveStudents(getStudentsFile());
        saveLibrarian(getLibrariansFile());

    }

    private void loadLibrarian(String lFile) {
        scanner=null;
        Formatter created = null;
        try {
            File check = new File(lFile);
            if(check.exists())
                scanner = new Scanner(new File(lFile));
            else {
                created = new Formatter(lFile);
                scanner = new Scanner(new File(lFile));
            }
            while (scanner.hasNext()) {
                String[] dataLine = scanner.nextLine().split(":");
                String lName = dataLine[0];
                String fName = dataLine[1];
                String userName = dataLine[2];
                String password = dataLine[3];
                Librarian lib = new Librarian(lName, fName, userName, password);
                library.getLibrarians().add(lib);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File to read librarian data not found");
        } catch (NumberFormatException nfe) {
            System.out.println("Incorrect input for loading library");
        }
    }

    private void saveLibrarian(String lFile){
        try{
            outputStream = new PrintStream(new FileOutputStream(lFile));
            String output = "";
            for (Librarian lib: library.getLibrarians()) {
                output = lib.getLName() + ":" + lib.getFName() + ":" + lib.getUserName() + ":" + lib.getPassword();
                outputStream.println(output);
            }
            outputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("File to save librarians not found.");
        }
    }

    public void rewritePassFiles(){
        outputStream = null;
        try{
            outputStream=new PrintStream(new FileOutputStream("adminPass.txt"));
            for (Librarian lib : library.getLibrarians())
                outputStream.println(lib.getUserName() + "\n" + lib.getPassword());

            outputStream=new PrintStream(new FileOutputStream("userPass.txt"));
            for (Student stud : library.getStudents())
                outputStream.println(stud.getUserName() + "\n" + stud.getPassword());

            outputStream.close();

        } catch (FileNotFoundException e) {
        }

    }

    public void createAdminUserFiles(){
        //Creates user and admin files on system startup
        Formatter created = null;
        File userFile = new File("userPass.txt");
        File adminFile = new File("adminPass.txt");
        try {
            if (!userFile.exists())
                created = new Formatter(userFile);
            if((!adminFile.exists())) {
                created = new Formatter(adminFile);
            }
        } catch(FileNotFoundException e) {
        }
        //Creates user and admin files on system startup
    }
}


