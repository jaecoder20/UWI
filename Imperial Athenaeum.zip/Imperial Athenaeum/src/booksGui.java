/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class booksGui extends javax.swing.JFrame {

    public booksGui() {
        library=Library.getLibrary();
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        setVisible(true);
    }
    private void initComponents() {

        author = new javax.swing.JLabel();
        title = new javax.swing.JLabel();
        authorTxt = new javax.swing.JTextField();
        titleTxt = new javax.swing.JTextField();
        addBookButton = new javax.swing.JButton();
        removeBookButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

        author.setText("Author Name:");

        title.setText("Title:");

        addBookButton.setText("Add Book");

        removeBookButton.setText("Delete Book");
        addBookButton.addActionListener(new addBookListener());
        removeBookButton.addActionListener(new removeBookListener());

        String[] columnNames=  {"Title",
                "Author","Available"};
        model=new DefaultTableModel(columnNames,0);
        jTable1 = new JTable(model);
        jScrollPane1.setViewportView(jTable1);
        //new LibraryManager().loadAllData();
        showBooks();

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(45, 45, 45)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(title)
                                                                .addGap(76, 76, 76)
                                                                .addComponent(titleTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(author)
                                                                .addGap(26, 26, 26)
                                                                .addComponent(authorTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(34, 34, 34)
                                                .addComponent(addBookButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(26, 26, 26)
                                                .addComponent(removeBookButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(124, 124, 124)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(author)
                                                        .addComponent(authorTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(title)
                                                        .addComponent(titleTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(74, 74, 74)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                        .addComponent(addBookButton)
                                                        .addComponent(removeBookButton)))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(30, 30, 30)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }



    public void showBooks()
    {
        model.setRowCount(0);
        ArrayList<Book> books =library.getBooks(); ;
        if (books.size()>0)
            for(int i=0;i<books.size();i++)
                addBookToTable(books.get(i));

    }
    private void addBookToTable(Book book){

        String title = book.getTitle();
        String author = book.getAuthor();
        String available = book.isBorrowed()?"No":"Yes";
        String[] item = {title,author,available};
        model.addRow(item);
    }

    private class addBookListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String author = authorTxt.getText();
            String title = titleTxt.getText();
            if(author.equals("")){
                JOptionPane.showMessageDialog(null,"Please enter the author's name");
            }
            else if(title.equals("")){
                JOptionPane.showMessageDialog(null,"Please enter the title");

            }
            else {
                Book book = library.searchBook(author, title);
                if (book != null) {
                    JOptionPane.showMessageDialog(null, "We already have " + title + " amongst our collection");
                    authorTxt.setText("");
                    titleTxt.setText("");
                }
                else {
                    authorTxt.setText("");
                    titleTxt.setText("");
                    library.addBook(title,author);
                    LibraryManager.getManager().saveAllData();
                    JOptionPane.showMessageDialog(null, title + " successfully added");
                    showBooks();
                }
            }
        }
    }
    private class removeBookListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String author = authorTxt.getText();
            String title = titleTxt.getText();
            Book book = library.searchBook(author, title);
            if (author.equals("")) {
                JOptionPane.showMessageDialog(null, "Please enter the author's name");
            } else if (title.equals("")) {
                JOptionPane.showMessageDialog(null, "Please enter the title");

            } else {
                if (book == null)
                    JOptionPane.showMessageDialog(null, "We do not possess the book " + title);
                else {
                    library.getBooks().remove(book);
                    LibraryManager.getManager().saveAllData();
                    JOptionPane.showMessageDialog(null, title + " successfully removed");
                    showBooks();
                }
            }
        }
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton addBookButton;
    private javax.swing.JButton removeBookButton;
    private javax.swing.JLabel author;
    private javax.swing.JLabel title;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField authorTxt;
    private javax.swing.JTextField titleTxt;
    private DefaultTableModel model;
    private Library library;
    // End of variables declaration                   
}