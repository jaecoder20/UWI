import java.util.ArrayList;

public class Student extends Account{
    private int age;
    private static int studentCounter = 0;
    private int studID;
    private ArrayList<Book> borrowedBooks;
    private Library library;


    public Student(String lName, String fName, int age, String userName, String password) {
        super(lName, fName, userName, password);
        this.age=age;
        studID = studentCounter++;
        library = Library.getLibrary();
        borrowedBooks = new ArrayList<Book>();

    }

    @Override
    protected boolean checkLogInfo() {
        return false;
    }
    public ArrayList<Book> getBorrowedBooks(){return borrowedBooks;}

    public int getStudID(){return studID;}
    public void borrowBook(Book book){
        borrowedBooks.add(book);
    }

    public Book searchBookByTitle(String title){
        Book book = null;
        for(Book bk: library.getBooks())
            if(title.equals(bk.getTitle())) {
                book = bk;
                book.setAsBorrowed();
            }
        return book;
    }

    public void addBorrowed(String title){
        //Since books are stored by titles, we must search for book with title before adding to arraylist
        borrowedBooks.add(searchBookByTitle(title));

    }

    public String toString(){
        return ""+getFName()+getLName()+getAge()+getUserName()+getPassword()+getStudID();
    }

    public Book searchBorrowed(String author, String title){
        //verifies if a student borrowed a book
        Book book=null;
        author = author.toUpperCase();
        title = title.toUpperCase();
        for(Book bk:getBorrowedBooks())
            if(bk.getAuthor().toUpperCase().equals(author)&&bk.getTitle().toUpperCase().equals(title))
                book=bk;
        return book;
    }
    public int getAge(){return age;}

}
