public class Book {
    private String title;
    private String authorName;
    private boolean borrowed;
    private Library library;

    public Book(String title, String authorName){
        this.authorName=authorName;
        this.title=title;
        borrowed = false;
        library= Library.getLibrary();
    }

    public String getAuthor(){return authorName;}
    public boolean isBorrowed(){return borrowed;}
    public void setAsBorrowed(){this.borrowed=true;}
    public void setNotBorrowed(){this.borrowed=false;}
    public String getTitle(){return title;}
    public String toString(){
        return ""+getTitle();
    }
}
