public class Librarian extends Account{
    private Library library;
    private static int librarianCounter=0;

    public Librarian(String lName, String fName, String userName, String password) {
        super(lName, fName, userName, password);
        library = Library.getLibrary();
        librarianCounter++;
    }

    @Override
    protected boolean checkLogInfo() {
        return false;
    }


}
