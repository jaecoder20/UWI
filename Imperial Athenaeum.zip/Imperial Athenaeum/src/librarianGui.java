import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class librarianGui extends JFrame {


    // Variables declaration - do not modify
    private javax.swing.JButton studentDetails;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton addNewStudent;
    private javax.swing.JButton sortByID;
    private javax.swing.JButton sortByAge;
    private javax.swing.JButton viewStudents;
    private javax.swing.JButton viewBooks;
    private javax.swing.JButton viewAccount;
    private DefaultTableModel model;
    private Librarian librarian;
    //private librarianGui sg;
    private JCheckBox borrowedScreen;
    private JCheckBox viewAllScreen;
    private Login log;
    private librarianGui libGui;

    public DefaultTableModel getModel(){return model;}
    public librarianGui(Librarian librarian, Login log) {
        super("WELCOME! This is your Librarian account, "+ log.getsubmittedUsername());
        this.log=log;
        //sg=this;
        this.libGui=this;
        setVisible(true);
        this.librarian=librarian;
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        viewAllScreen.setSelected(true);

    }

    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        viewBooks = new javax.swing.JButton();
        viewStudents = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        sortByID = new javax.swing.JButton();
        sortByAge = new javax.swing.JButton();
        studentDetails = new javax.swing.JButton();
        addNewStudent = new javax.swing.JButton();
        borrowedScreen = new JCheckBox();
        viewAllScreen = new JCheckBox();
        viewAccount=new JButton();
        viewAccount.setText("View Account");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        viewBooks.setText("View Books");
        viewBooks.addActionListener(new viewBooks());

        viewStudents.setText("View Students");
        viewStudents.addActionListener(new viewAllStudents());
        sortByID.addActionListener(new IDSortButton());
        sortByAge.addActionListener(new ageSortButton());
        studentDetails.addActionListener(new studentDetailsButton());
        addNewStudent.addActionListener(new addNewStudentButton());
        viewAccount.addActionListener(new viewAccountButton());


        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(124, 124, 124)
                                .addComponent(viewBooks)
                                .addGap(124, 124, 131)
                                .addComponent(viewStudents)
                                .addGap(124, 124, 131)
                                .addComponent(viewAccount)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(viewBooks)
                                        .addComponent(viewStudents)
                                        .addComponent(viewAccount))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

//        jTable1.setModel(new javax.swing.table.DefaultTableModel(
//                new Object [][] {
//                        {null, null},
//                        {null, null},
//                        {null, null},
//                        {null, null}
//                },
//                new String [] {
//                        "Title", "Author"
//                }
//        ));

        String[] columnNames=  {"ID",
                "Username","Age"};
        model=new DefaultTableModel(columnNames,0);
        jTable1 = new JTable(model);
        jTable1.setFocusable(false);
        jTable1.setRowHeight(25);
        jTable1.setSelectionBackground(new java.awt.Color(232, 57, 95));
        jTable1.setShowGrid(false);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        //new LibraryManager().loadAllData();
        showStudents();
        jTable1.setSelectionBackground(new java.awt.Color(255, 251, 0));
        jTable1.setShowHorizontalLines(true);
        jTable1.setShowVerticalLines(true);
        jScrollPane1.setViewportView(jTable1);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        sortByID.setText("Sort By ID");

        sortByAge.setText("Sort By Age");

        studentDetails.setText("See Student Details");

        addNewStudent.setText("Add New Student");
        showStudents();
        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(sortByID)
                                .addGap(62, 62, 62)
                                .addComponent(sortByAge)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                                .addComponent(studentDetails)
                                .addGap(68, 68, 68)
                                .addComponent(addNewStudent)
                                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(sortByAge)
                                        .addComponent(sortByID)
                                        .addComponent(studentDetails)
                                        .addComponent(addNewStudent))
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1)
                                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(8, Short.MAX_VALUE))
        );

        pack();
    }
    private class viewAllStudents implements ActionListener{

        public void actionPerformed(ActionEvent e) {
            showStudents();
        }
    }

    private class viewBooks implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new booksGui();

        }
    }
    private class viewAccountButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new librarianAccountView(librarian,libGui);

        }
    }
    private class studentDetailsButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            new studentDetailsGui(libGui);
        }
    }
    private class addNewStudentButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(null, "Please note the student's Imperial username " +
                    "shall be set to his/her full name.");
            new newstudent(libGui);


        }
    }
    private class IDSortButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Collections.sort(Library.getLibrary().getStudents(), new sortByID());
            showStudents();

        }
    }
    private class ageSortButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Collections.sort(Library.getLibrary().getStudents(), new sortByAge());
            showStudents();

        }
    }

    private void addStudentToTable(Student stud){
        String ID = stud.getStudID()+"";
        String username = stud.getUserName();
        String age = stud.getAge()+"";
        String[] item = {ID,username,age};
        model.addRow(item);


    }

    public void showStudents()
    {
        model.setRowCount(0);
        ArrayList<Student> students = Library.getLibrary().getStudents();
        if (students.size()>0)
            for(int i=0;i<students.size();i++)
                    addStudentToTable(students.get(i));

    }








}