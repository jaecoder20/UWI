public abstract class Account {
    private String lName;
    private String fName;
    protected String userName;
    protected String password;

    public Account(String lName, String fName, String userName, String password){
        this.lName=lName;
        this.fName=fName;
        this.userName=userName;
        this.password=password;

    }

    public String getLName(){return lName;}
    public String getFName(){return fName;}
    protected String getPassword(){return password;}
    protected String getUserName(){return userName;}


    protected boolean checkPass(String pass){return this.password.equals(pass);}
    protected boolean checkUName(String uname){return this.userName.equals(uname);}

    protected abstract boolean checkLogInfo();//will use checkpass and checkuname

    public void setPassword(String pass){
        this.password=pass;
    }

}
