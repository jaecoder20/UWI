/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;


public class showStudentDetails extends javax.swing.JFrame {


    public showStudentDetails(Student student,librarianGui librarianGui) {
        this.libGui=librarianGui;
        this.library=Library.getLibrary();
        this.student=student;
        setVisible(true);
        initComponents();
        unameText.setText(student.getUserName());
        ageText.setText(student.getAge()+"");
        idText.setText(student.getStudID()+"");

    }


    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        studentDetails = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bookBLabel = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        usernameLabel = new javax.swing.JLabel();
        ageLabel = new javax.swing.JLabel();
        IDLabel = new javax.swing.JLabel();
        unameText = new javax.swing.JLabel();
        ageText = new javax.swing.JLabel();
        idText = new javax.swing.JLabel();
        sortByAuthor = new javax.swing.JButton();
        sortByTitle = new javax.swing.JButton();
        deleteStudent = new javax.swing.JButton();

        sortByAuthor.addActionListener(new authorSortListener());
        sortByTitle.addActionListener(new titleSortListener());
        deleteStudent.addActionListener(new deleteStudentListener());

        setDefaultCloseOperation(HIDE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 0));

        studentDetails.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        studentDetails.setText("Details On Student");

        String[] columnNames=  {"Title",
                "Author"};
        model=new DefaultTableModel(columnNames,0);
        jTable1 = new JTable(model);
        jScrollPane1.setViewportView(jTable1);
        showBooks();

        bookBLabel.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        bookBLabel.setText("Books Borrowed");

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(0, 0, 0), null, null));

        usernameLabel.setText("Username:");

        ageLabel.setText("Age:");

        IDLabel.setText("ID:");

        unameText.setText("uname");

        ageText.setText("age");

        idText.setText("id");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(usernameLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(unameText))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(ageLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(ageText))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(IDLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(idText)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(usernameLabel)
                                        .addComponent(unameText))
                                .addGap(33, 33, 33)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(ageLabel)
                                        .addComponent(ageText))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(IDLabel)
                                        .addComponent(idText))
                                .addGap(21, 21, 21))
        );

        sortByAuthor.setText("Sort By Author");

        sortByTitle.setText("Sort By Title");

        deleteStudent.setText("Delete This Student");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addGap(124, 124, 124)
                                                .addComponent(studentDetails)
                                                .addGap(0, 0, Short.MAX_VALUE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(deleteStudent, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addComponent(sortByAuthor)
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                                                                .addComponent(sortByTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                                .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(bookBLabel)
                                .addGap(76, 76, 76))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(studentDetails)
                                .addGap(25, 25, 25)
                                .addComponent(bookBLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(37, 37, 37)
                                                .addComponent(deleteStudent)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(sortByAuthor)
                                        .addComponent(sortByTitle))
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();

        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
    }



    private class authorSortListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            Collections.sort(student.getBorrowedBooks(), new authorSort());
            showBooks();
        }
    }
    private class titleSortListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            Collections.sort(student.getBorrowedBooks(), new titleSort());
            showBooks();
        }
    }
    private class deleteStudentListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            library.selfRemoveAccount(student);
            JOptionPane.showMessageDialog(null,unameText.getText()+" was successfully deleted");
            setVisible(false);
            libGui.showStudents();
            LibraryManager.getManager().saveAllData();
        }
    }
    public void showBooks()
    {
        model.setRowCount(0);
        ArrayList<Book> books =this.student.getBorrowedBooks();
        if (books.size()>0)
            for(int i=0;i<books.size();i++)
                addBookToTable(books.get(i));

    }
    private void addBookToTable(Book book){

        String title = book.getTitle();
        String author = book.getAuthor();
        String[] item = {title,author};
        model.addRow(item);
    }
    // Variables declaration - do not modify
    private javax.swing.JLabel IDLabel;
    private javax.swing.JLabel ageLabel;
    private javax.swing.JLabel ageText;
    private javax.swing.JLabel bookBLabel;
    private javax.swing.JButton deleteStudent;
    private javax.swing.JLabel idText;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton sortByAuthor;
    private javax.swing.JButton sortByTitle;
    private javax.swing.JLabel studentDetails;
    private javax.swing.JLabel unameText;
    private javax.swing.JLabel usernameLabel;
    private DefaultTableModel model;
    private Student student;
    private Library library;
    private librarianGui libGui;
    // End of variables declaration
}
