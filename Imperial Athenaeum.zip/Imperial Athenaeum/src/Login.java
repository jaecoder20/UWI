import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.logging.Logger;

public class Login extends JFrame {
    private JButton blogin;
    private JPanel loginpanel;
    private JTextField txuser;
    private JTextField pass;
    private JButton newUSer;
    private JLabel username;
    private JLabel password;
    private JCheckBox admin;
    private Login log;
    public String getsubmittedUsername(){return txuser.getText();}

    public Login() throws IOException {
        super("Login Authentication");
        this.log=this;
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);

        blogin = new JButton("Login");
        loginpanel = new JPanel();
        txuser = new JTextField(15);
        pass = new JPasswordField(15);
        newUSer = new JButton("New User?");
        username = new JLabel("Username ");
        password = new JLabel("Password ");
        admin = new JCheckBox("Librarian");

        setSize(300, 250);
        setLocation(500, 280);
        loginpanel.setLayout(null);


        txuser.setBounds(80, 30, 150, 26);
        pass.setBounds(80, 65, 150, 23);
        blogin.setBounds(90, 130, 150, 20);
        newUSer.setBounds(90, 165, 150, 20);
        username.setBounds(20, 33, 80, 20);
        password.setBounds(20, 66, 80, 20);
        admin.setBounds(80, 85, 95, 30);

        loginpanel.add(blogin);
        loginpanel.add(txuser);
        loginpanel.add(pass);
        loginpanel.add(newUSer);
        loginpanel.add(username);
        loginpanel.add(password);
        loginpanel.add(admin);

        getContentPane().add(loginpanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        Writer writer = null;
        File check = new File("userPass.txt");
        if (!check.exists()) {
            try {
                File texting = new File("userPass.txt");
                writer = new BufferedWriter(new FileWriter(texting));
                writer.write("message");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            check = new File("adminPass.txt");
            if (!check.exists()) {
                try {
                    File texting = new File("adminPass.txt");
                    writer = new BufferedWriter(new FileWriter(texting));
                    writer.write("message");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


        blogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (admin.isSelected()) {
                        AdminLogin();
                    }else{
                        UserLogin();//ie student login

                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        newUSer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    SignUp newUser = new SignUp();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                dispose();

            }
        });
    }
    public void AdminLogin() throws IOException {
        File file = new File("adminPass.txt");
        Scanner scan = new Scanner(file);
        String line = null;
        FileWriter filewrite = new FileWriter(file, true);

        String usertxt = " ";
        String passtxt = " ";
        String puname = txuser.getText();
        String ppaswd = pass.getText();
        boolean access = false;



        while (scan.hasNext()) {
            usertxt = scan.nextLine();
            passtxt = scan.nextLine();

            for(int i =0;puname.equals(usertxt) && ppaswd.equals(passtxt);i++ ){

                //MainMenu menu =new MainMenu();
                JOptionPane.showMessageDialog(null, "Entry Granted");
                access=true;
                dispose();
                Librarian librarian = Library.getLibrary().findLibrarian(txuser.getText());
                new librarianGui(librarian,log);
                break;

            }

        }

        if (!access) {
            if (puname.equals("") && ppaswd.equals("")){
                JOptionPane.showMessageDialog(null, "Please insert Username and Password");
            }else if (!puname.equals(usertxt) && !ppaswd.equals(passtxt)){
                JOptionPane.showMessageDialog(null, "Wrong Username / Password");
                txuser.setText("");
                pass.setText("");
                txuser.requestFocus();

            }
        }}

    public void UserLogin() throws IOException {
        File file = new File("userPass.txt");
        Scanner scan = new Scanner(file);
        String line = null;
        FileWriter filewrite = new FileWriter(file, true);

        String usertxt = " ";
        String passtxt = " ";
        String puname = txuser.getText();
        String ppaswd = pass.getText();
        boolean access = false;



        while (scan.hasNext()) {
            usertxt = scan.nextLine();
            passtxt = scan.nextLine();

            for(int i =0;puname.equals(usertxt) && ppaswd.equals(passtxt);i++ ){

                //MainMenu menu =new MainMenu();
                JOptionPane.showMessageDialog(null, "Entry Granted");
                access=true;
                dispose();
                //System.out.println(username.getText());
                Student stud = Library.getLibrary().findStudent(txuser.getText());
                new studentGui(stud,log);
                break;

            }

        }

        if (!access) {
            if (puname.equals("") && ppaswd.equals("")){
                JOptionPane.showMessageDialog(null, "Please insert Username and Password");
            }else if (!puname.equals(usertxt) && !ppaswd.equals(passtxt)){
                JOptionPane.showMessageDialog(null, "Wrong Username / Password");
                txuser.setText("");
                pass.setText("");
                txuser.requestFocus();

            }
        }
    }

}