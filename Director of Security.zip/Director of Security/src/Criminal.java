
public class Criminal
{
    private boolean arrested;
    private boolean rehabilitated;
    private String name;
    private boolean alive;

    public Criminal(String name)
    {
        arrested = false;
        rehabilitated = false;
        this.name= name;
        alive=true;
    }

    public void killed(){this.alive=false;}
    public boolean isAlive(){return alive;}


    public void arrest(){
        arrested = true;
    }

    public String getName(){

        return name;
    }


    public void rehabilitate(){
        rehabilitated = true;
    }

    public String toString(){
        return name;

    }

}
