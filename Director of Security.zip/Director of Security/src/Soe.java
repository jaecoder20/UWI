public class Soe extends Zoso {
    private int numRehab;

    //Method signature different from canDeploy method in Zoso
    //Also, since canDeploy methods are static, no overriding takes place.
    public static boolean canDeploy(int reqTeamSize){
        //this method was made static to allow it to be accessed without a Soe object
        //Two officers are needed for an Soe
        Services s =  Services.getService();
        return s.soldiersAvailable(reqTeamSize) && s.socialAvailable(reqTeamSize) && s.policeAvailable(2);
    }
    public Soe(Community community, int teamSize, int rehabRate, int deathRate)
    {
        super(community, teamSize, deathRate);
        Services service =  Services.getService();
        /* Since Soe is a child of Zoso, the following were not implemented in its constructor:
        **for loop to arrest all criminals
        **Counting of criminals
        **deployment of soldiers and 1 police officer
        All the above were carried out when the super keyword was used to call the constructor of Zos
        Zoso all stores numArrests which is inherited by Soe*/
        service.deploySocial(teamSize);
        numRehab = countArrests()*rehabRate/100;

        for(int i=0;i<numRehab;i++){
            //This block of code rehabilitates and removes a number of criminals based on numRehab
            //Adds the criminal to the resident arraylist of the...
            // ...community by creating a new Resident using the criminal's name
            Criminal crim = community.getCriminals().get(0);
            crim.rehabilitate();
            community.getCriminals().remove(0);
            community.getResidents().add(new Resident(crim.getName(),community));
        }
        setOpsName("SOE");

    }

    public int getNumRehab(){return numRehab;}

    public String toString()
    {

        String str = numRehab == 0? "Operation " + super.getCallSign() + " to be deployed as a SOE in " + cm.getName() +
                ".\nExpect " + countArrests() + " arrest(s)." : //If numRehab is not equal to 0 then the toString...
                // ...format below is used instead
                "Operation " + super.getCallSign() + " to be deployed " +
                "as a SOE in " + cm.getName() + ".\nExpect " + countArrests() + " arrest(s) and " + numRehab + " " +
                "rehabilitation(s).";

        return str;
    }


}
