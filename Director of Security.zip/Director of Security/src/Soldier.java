public class Soldier extends BaseWorker{

    public Soldier(String name, int age, boolean publish) {
        super(name, age, publish);

    }
}
