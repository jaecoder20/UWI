import java.security.Provider;

public class Raid extends Operation
{
    //ATTRIBUTE
    private int numArrests;
    private int numPoliceDead;
    private int numCrimDead;

    public static boolean canDeploy(int reqTeamSize){
        //this method was made static to allow it to be accessed without a Raid object
        Services service =  Services.getService();
        return service.policeAvailable(reqTeamSize);
    }

    public Raid(Community community, int teamSize, int deathRate)
    {
        super(community);
        //Implements the arrest of all criminals in the community
        for(Criminal crim: community.getCriminals())
            crim.arrest();
        this.numArrests = community.countCriminals();
        Services.getService().deployPolice(teamSize);
        numPoliceDead = teamSize*deathRate/100;
        numCrimDead = community.countCriminals()*deathRate/100;
        Services services = Services.getService();
        for(int i=0;i< numPoliceDead;i++)
            services.getDeployList_police().get(i).killed();
        for(int i=0;i< numCrimDead;i++)
            community.getCriminals().get(i).killed();
        setOpsName("Raid");


    }
    public int countArrests(){
        return numArrests;
    }
    public String toString(){
        String str = "Operation " +super.getCallSign() + " to be deployed as a Raid in " +cm.getName()+
                ".\nExpect "+countArrests() +" arrest(s).";

        return str;
    }
    public int getNumWorkersDead(){return numPoliceDead;}
    public int getNumCrimDead(){return numCrimDead;}

}

