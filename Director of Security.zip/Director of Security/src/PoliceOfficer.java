public class PoliceOfficer extends BaseWorker{
    public PoliceOfficer(String name, int age, boolean publish){
        super(name,age,publish);
    }
}
