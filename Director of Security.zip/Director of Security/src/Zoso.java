public class Zoso extends Operation {
    private int numArrests;
    private int numSoldiersDead;
    private int numCrimDead;

    public Zoso(Community community, int teamSize, int deathRate)
    {
        super(community);
        //Implements the arrest of all criminals in the community
        for(Criminal crim: community.getCriminals())
            crim.arrest();
        numArrests = community.countCriminals();
        Services.getService().deploySoldiers(teamSize);
        numSoldiersDead = teamSize*deathRate/100;
        numCrimDead = community.countCriminals()*deathRate/100;
        Services services = Services.getService();
        for(int i=0;i< numSoldiersDead;i++)
            services.getDeployList_soldier().get(i).killed();
        for(int i=0;i< numCrimDead;i++)
            community.getCriminals().get(i).killed();
        setOpsName("ZOSO");

    }

    public static boolean canDeploy(int deploySize)
    {//this method was made static to allow it to be accessed without a Zoso object
        Services service = Services.getService();
        return (service.soldiersAvailable(deploySize)) && (service.policeAvailable(1));
    }
    public int countArrests()
    {
        return numArrests;
    }
    public String toString()
    {
        String str = "Operation " +super.getCallSign() + " to be deployed as a ZOSO in " +cm.getName()+
                ".\nExpect "+countArrests() +" arrest(s).";

        return str;
    }
    public int getNumWorkersDead(){return numSoldiersDead;}
    public int getNumCrimDead(){return numCrimDead;}
}
