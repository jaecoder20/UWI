import java.io.*;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Scanner;

public class Driver //was saved
{

    public static void main(String[] args) {
        final int forceMultiplier=3, gangLimit=10, rehabRate=20, deathRate=30;
        DoS dos = null;
        Scanner scan = new Scanner(System.in);
        try{
            System.out.println("Enter the total number of supplies available for social use (food, clothes, beds)");
            int numSupplies = Integer.parseInt(scan.nextLine());
            System.out.println("Enter the total number of equipment available to soldiers");
            int numEquipment = Integer.parseInt(scan.nextLine());
            dos = new DoS(forceMultiplier,gangLimit,rehabRate,numEquipment,numSupplies,deathRate);


        }catch(NumberFormatException nfe){
            System.out.println("Issue");
        }

        System.out.println("Select D/d for Data Entry Mode or A/a for Action mode");
        String mode = scan.next().toUpperCase();

        if(mode.equals("D")){
            EntryScreen ec = new EntryScreen();
            System.out.println("");
            System.out.println("");
            System.out.println("===========What would you like to enter into the System?=============");
           // System.out.println("[S]oldier Entry\nSocial [W]orker Entry info\n[P]olice Officer Entry\n[E]xit");
            System.out.println("");
            char entryChoice = 'F';
            Services service = Services.getService();
//            String menu = scan.next().toUpperCase();
//            entryChoice = menu.charAt(0);

            while (entryChoice!='E' && entryChoice!='A') {
                try {
                    System.out.println("[S]oldier Entry\nSocial [W]orker Entry\n[P]olice Officer Entry\n[E]xit\n[A]ction Mode");
                    String menu = scan.next().toUpperCase();
                    entryChoice = menu.charAt(0);
                    switch (entryChoice) {
                        case 'S': {
                            Soldier soldier = ec.getSoldier(scan);
                            if (soldier != null) {
                                service.getSoldierList().add(soldier);
                            } else {
                                System.out.println("Error, soldier not added");
                            }
                            break;
                        }
                        case 'W': {
                            SocialWorker social = ec.getSocialWorker(scan);
                            if (social != null) {
                                service.getSocialList().add(social);
                            } else {
                                System.out.println("Error, social worker not added");
                            }
                            break;
                        }
                        case 'P': {
                            PoliceOfficer officer = ec.getOfficer(scan);
                            if (officer != null) {
                                service.getPoliceList().add(officer);
                            } else {
                                System.out.println("Error, officer not added");
                            }
                            break;

                        }
                        case 'A': {
                            try {
                                dos.actionMode(scan);
                                break;
                            } catch (InterruptedException e) {}


                        }
                        case 'E':{
                            System.out.println("See you next time");
                            System.exit(0);
                        }

                    }
                }catch(NumberFormatException nfe){}
            }



        }else if(mode.equals("A"))
            try {
                dos.actionMode(scan);
            } catch (InterruptedException e) {}






    }
}
