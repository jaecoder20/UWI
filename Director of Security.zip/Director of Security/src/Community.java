import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Community
{
    private double GPSx, GPSy;
    private String name;
    private ArrayList<Resident> residents=new ArrayList<Resident>();
    private ArrayList<Criminal> criminals= new ArrayList<Criminal>();

    public Community(String name, double GPSx, double GPSy)
    {
        this.GPSx=GPSx;
        this.GPSy=GPSy;
        this.name = name;


    }


    public double getGPSx(){return GPSx;}
    public double getGPSy(){return GPSy;}



    public int countResidents(){
        return residents.size();
    }

    public int countCriminals(){
        return criminals.size();
    }


    public ArrayList<Criminal> getCriminals(){
        return criminals;
    }
    public ArrayList<Resident> getResidents(){
        return residents;
    }

    public Resident getResident(String name)
    {
        Resident retval =  null;
        for (Resident g:residents)
            if (g.getName().equals(name))
                retval = g;
        if (retval==null)
        {
            retval = new Resident(name, this);
            residents.add(retval);
        }
        return retval;
    }
    public void assessForOp() {

    }

    public Criminal getCriminal(String name)
    {
        Criminal retval =  null;
        for (Criminal c:criminals)
            if (c.getName().equals(name))
                retval = c;
        if (retval==null)
        {
            retval = new Criminal(name);
            criminals.add(retval);
        }
        return retval;
    }

    public String getName(){
        return name;
    }

//    public String toString(){
//        String str = "=======================\n";
//        str+="======"+name+"("+residents.size()+")=========\n";
//        str+="========Residents=========\n";
//        for(Resident r:residents)
//            str+=r+"\n";
//        str+="-----Criminals--------\n";
//        for(Criminal c:criminals)
//            str+=c+"\n";
//        str+="----------------------\n";
//
//        return str;
//    }

    public ArrayList<Resident> loadResidents(String resFile){
        Scanner scan = null;
        try {
            scan = new Scanner(new File(resFile));
            while (scan.hasNext()) {
                String vcLine = scan.nextLine();
                String[] dataLine = vcLine.split(" ");
                String name = dataLine[0]+ " " + dataLine[1];
                residents.add(new Resident(name, this));
            }
            scan.close();
        }catch(IOException io){}


        return residents;
    }
    public ArrayList<Criminal> loadCriminals(String crimFile, int numCriminals){
        Scanner scan = null;
        try {
            scan = new Scanner(new File(crimFile));
            int i =0;
            while (scan.hasNext()&&i<numCriminals) {
                String vcLine = scan.nextLine();
                String[] dataLine = vcLine.split(" ");
                String name = dataLine[0]+" "+dataLine[1];
                if(dataLine.length>2)
                    name+= " "+dataLine[2];
                criminals.add(new Criminal(name));
                i++;
            }
            scan.close();
        }catch(IOException io){}


        return criminals;
    }

    public void loadComminity(int numCriminals)
    {
        residents = loadResidents(getResidentsInFile());
        criminals = loadCriminals(getCriminalsInFile(), numCriminals);
    }

    public String getResidentsInFile()
    {
        return "./residents.txt";

    }
    public String getCriminalsInFile()
    {
        return "./criminals.txt";

    }

    public void printAllResidents(){
        for(Resident r: residents)
            System.out.println(r);
    }
    public void printAllCriminalsCaptured(){
        System.out.println("==========="+countCriminals()+ " Criminals were arrested===========");
        System.out.println("");
        for(Criminal c: criminals)
            if(c.isAlive())
                System.out.println(c);
            else
                System.out.println(c+" was killed during the Operation.");

    }


}



















































