import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Services //handles all the resources of the system
{
    private ArrayList<Soldier> slist= new ArrayList<Soldier>();
    private ArrayList<SocialWorker> sociList = new ArrayList<SocialWorker>();
    private ArrayList<PoliceOfficer> officerList = new ArrayList<PoliceOfficer>();
    private ArrayList<PoliceOfficer> deployList_police= new ArrayList<PoliceOfficer>();
    private ArrayList<Soldier> deployList_soldier= new ArrayList<Soldier>();
    private ArrayList<SocialWorker> deployList_soci= new ArrayList<SocialWorker>();
    private int numEquipment;
    private int numSupplies;
    private static Services theService;

    public ArrayList<Soldier> getSoldierList(){return slist;}
    public ArrayList<PoliceOfficer> getPoliceList(){return officerList;}
    public ArrayList<SocialWorker> getSocialList(){return sociList;}


    public Services(int numEquipment,int numSupplies){
        this.numEquipment=numEquipment;
        this.numSupplies=numSupplies;
    }


    public static Services getService(int numEquipment, int numSupplies){
        if (theService==null)
            theService = new Services(numEquipment,numSupplies);

        return theService;
    }


    public static Services getService(){
        return theService;
    }
    public int countDeployedSoldiers(){return deployList_soldier.size();}
    public int countDeployedPolice(){return deployList_police.size();}
    public int countDeployedSoci(){return deployList_soci.size();}
    public ArrayList<Soldier> getDeployList_soldier(){return deployList_soldier;}
    public ArrayList<PoliceOfficer> getDeployList_police(){return deployList_police;}
    public ArrayList<SocialWorker> getDeployList_soci(){return deployList_soci;}




    public boolean policeAvailable(int req)
    {
        return officerList.size()>=req;
    }

    public boolean soldiersAvailable(int req)
    {
        return ((slist.size()>=req) &&
                (numEquipment >= req));
    }


    public void deployPolice(int numNeeded){
        for (int i=0;i< numNeeded;i++) {
            deployList_police.add(officerList.get(0));
            officerList.remove(0);
        }
    }

    public void deploySoldiers(int numNeeded){
        //deploys 1 police officer and a number of soldiers
        try {

            deployList_police.add(officerList.get(0));
            officerList.remove(0);
            for (int i = 0; i < numNeeded; i++) {
                deployList_soldier.add(slist.get(0));
                slist.remove(0);
            }
        }catch(IndexOutOfBoundsException ibe){}
        numEquipment -= numNeeded;
    }
    public boolean socialAvailable(int deploymentSize)
    {
        return ((sociList.size()>=deploymentSize)&&(numSupplies>=deploymentSize));
    }

    public void deploySocial(int deploymentSize)//exception handling necessary?
    {
        deployList_police.add(officerList.get(0));
        officerList.remove(0);
        for(int i=0;i<deploymentSize;i++) {
            deployList_soci.add(sociList.get(0));
            sociList.remove(0);
        }
        numSupplies -= deploymentSize;

    }

    public ArrayList<Soldier> loadSoldiers(String soldiersFile){
        Scanner sScan = null;
        try {
            sScan = new Scanner(new File(soldiersFile));
            while (sScan.hasNext()) {
                String vcLine = sScan.nextLine();
                String[] dataLine = vcLine.split(" ");
                String name = dataLine[0]+" "+dataLine[1];
                int age = Integer.parseInt(dataLine[2]);
                int publish = Integer.parseInt(dataLine[3]);
                boolean pub = publish == 1;
                slist.add(new Soldier(name, age, pub));
            }
            sScan.close();
        }catch(IOException io){
            System.out.println("soldier");
        }


        return slist;
    }
    public ArrayList<PoliceOfficer> loadPolice(String policeFile){
        Scanner pscan = null;
        try {
            pscan = new Scanner(new File(policeFile));
            while (pscan.hasNext()) {
                String vcLine = pscan.nextLine();
                String[] dataLine = vcLine.split(" ");
                String name = dataLine[0]+" "+dataLine[1];
                int age = Integer.parseInt(dataLine[2]);
                int publish = Integer.parseInt(dataLine[3]);
                boolean pub = publish == 1;
                officerList.add(new PoliceOfficer(name, age, pub));
            }
            pscan.close();
        }catch(IOException io){
            System.out.println("police");
        }


        return officerList;
    }

    public ArrayList<SocialWorker> loadSocial(String policeFile){
        Scanner scan = null;
        try {
            scan = new Scanner(new File(policeFile));
            while (scan.hasNext()) {
                String vcLine = scan.nextLine();
                String[] dataLine = vcLine.split(" ");
                String name = dataLine[0]+" "+dataLine[1];
                int age = Integer.parseInt(dataLine[2]);
                sociList.add(new SocialWorker(name, age,true));
            }
            scan.close();
        }catch(IOException io){
            System.out.println("social");
        }


        return sociList;
    }

    public void loadData()
    {
        slist =  loadSoldiers(getSoldierInFile());
        officerList = loadPolice(getPoliceInFile());
        sociList = loadSocial(getSocialInFile());
    }

    public String getSoldierInFile()
    {
        return "./soldiers.txt";

    }
    public String getSocialInFile()
    {
        return "./socialworkers.txt";

    }

    public String getPoliceInFile()
    {
        return "./police.txt";

    }

    public void printAllSoliders(PrintStream outstream){
        for(Soldier s: slist)
            outstream.println(s);
    }
    public void printAllSoci(PrintStream outstream){
        for(SocialWorker sw: sociList)
            outstream.println(sw);
    }
    public void printAllPolice(PrintStream outstream){
        for(PoliceOfficer po: officerList)
            outstream.println(po);
    }

//    public void printDeadPolice(){
//        System.out.println("=========Officers Killed in Action=========");
//        for(PoliceOfficer po: officerList){
//            if(!po.isAlive() && po.getPublish())
//                System.out.println(po.getName());
//            else if(!po.isAlive() && !po.getPublish())
//                System.out.println("[Redacted] Officer");
//        }
//    }
//    public void printDeadSoldiers(){
//        System.out.println("=========Soldiers Killed in Action=========");
//        for(Soldier s: slist){
//            if(!s.isAlive() && s.getPublish())
//                System.out.println(s.getName());
//            else if(!s.isAlive() && !s.getPublish())
//                System.out.println("[Redacted] Soldier");
////        }
//
//
//        }
    public void printDeployedSoldiers(){
        System.out.println(countDeployedSoldiers()+" Soldiers were Deployed: ");
        System.out.println("");
        for(Soldier ds: deployList_soldier)
            if(ds.getPublish())
                if(ds.isAlive())
                    System.out.println(ds.getName()+" was deployed.");
                else
                    System.out.println(ds.getName()+" was deployed but KIA.");
            else
                if(ds.isAlive())
                    System.out.println("[Redacted] was deployed.");
                else
                    System.out.println("[Redacted] was deployed but KIA.");

    }

    public void printDeployedOfficers(){
        String title = countDeployedPolice()>1?countDeployedPolice()+" Officers were Deployed: ": countDeployedPolice()+" Officer was Deployed: ";
        System.out.println(title);
        System.out.println("");
        for(PoliceOfficer police: deployList_police)
            if(police.getPublish())
                if(police.isAlive())
                    System.out.println(police.getName()+" was deployed.");
                else
                System.out.println(police.getName()+" was deployed but KIA.");
            else
                if(police.isAlive())
                    System.out.println("[Redacted] was deployed.");
                else
                    System.out.println("[Redacted] was deployed but KIA.");

    }
    public void printDeployedSocial(){
        System.out.println(countDeployedSoci()+" Social Workers were Deployed: ");
        System.out.println("");
        for(SocialWorker soci: deployList_soci)
            if(soci.getPublish())
                System.out.println(soci.getName()+" was deployed.");
            else
                System.out.println("[Redacted] was deployed.");

    }

    public void printAllDeployed(){
        System.out.println("===========All Workers Deployed===========");
        System.out.println("");
        printDeployedSoldiers();
        System.out.println("");
        printDeployedOfficers();
        System.out.println("");
        printDeployedSocial();
        System.out.println("");
    }



}


