import java.lang.management.OperatingSystemMXBean;
import java.util.ArrayList;
import java.util.Scanner;

public class DoS
{
    private Community community;//change from array?
    private Operation operation;
    private EntryScreen ec;
    private Services activeService;
    private  int forceMultiplier, gangLimit, rehabRate, deathRate;

    public DoS(int forceMultiplier, int gangLimit,int rehabRate,int numEquipment, int numSupplies, int deathRate)
    {
        activeService = Services.getService(numEquipment,numSupplies);
        activeService.loadData();
        this.forceMultiplier = forceMultiplier;
        this.gangLimit = gangLimit;
        this.rehabRate = rehabRate;
        this.deathRate=deathRate;
        this.ec = new EntryScreen();
    }
    public void actionMode(Scanner scan) throws InterruptedException {
        this.community = ec.getCommunity(scan);
        scan = new Scanner(System.in);
        int num = 0;
        try {
            System.out.println("How many criminals were reported by residents? (Not more than 10 for now)");
            num = Integer.parseInt(scan.nextLine());
        }catch(NumberFormatException nfe){}
        if(this.community!=null){
            this.community.loadComminity(num);
        }else{
            System.out.println("Community not loaded successfully ");
        }
        System.out.print("Now evaluating "+community.getName()+" to determine appropriate actions");
        for(int i=0;i<3;i++) {
            Thread.sleep(800);
            System.out.print(".");
        }
        Thread.sleep(800);
        System.out.println("");
        System.out.println("");
        assessForOps();
        //System.out.println(operation.toString());
        fullReport();



    }

    public Services getService(){
        return activeService;
    }

    public int getForceMultiplier(){
        return forceMultiplier;
    }

    public int getGangLimit(){
        return gangLimit;
    }

    public void takeReport (String report)
    {
        //implementation?

    }

    public String deploymentPlan()
    {
        return "";
        //Implementation? Could be used to give details of deployment action on a community in terms of
        // resources used, troops/workers deployed on community.name etc


    }

    public Community getCommunity(){
        return community;
    }

    public void assessForOps(){
        double emergencyRatio = 0.3;
        int numCriminals=this.community.countCriminals();
        int numResidents = this.community.countResidents();
        if (numCriminals >0){
            if (numCriminals<gangLimit)
            {
                if (Raid.canDeploy(numCriminals*forceMultiplier))
                    this.operation = (new Raid(this.community,numCriminals*forceMultiplier,deathRate));
                else if (UnderCover.canDeploy())
                    this.operation = (new UnderCover(this.community));

            }
            if((numCriminals>=gangLimit)&&(numCriminals<emergencyRatio*numResidents)) {
                if (Zoso.canDeploy(numCriminals * forceMultiplier))
                    this.operation = (new Zoso(this.community, numCriminals * forceMultiplier,deathRate));
                else if (UnderCover.canDeploy())
                    this.operation = (new UnderCover(this.community));
            }else if((numCriminals>=gangLimit)&&(numCriminals>=emergencyRatio*numResidents)) {
                if (Soe.canDeploy(numCriminals * forceMultiplier))
                        this.operation = (new Soe(this.community, numCriminals * forceMultiplier, rehabRate,deathRate));
                else if (UnderCover.canDeploy())
                    this.operation = (new UnderCover(this.community));
            }




            }



        }


        public void fullReport(){
            System.out.println("=============Full Report For "+this.community.getName()+"=============");
            System.out.println("");
            System.out.println("Located at:");
            System.out.println("Latitude: "+this.community.getGPSx()+"°");
            System.out.println("Longitude: "+this.community.getGPSy()+"°");
            System.out.println("Operation carried out: "+this.operation.getOpsName());
            System.out.println("");
            System.out.println("");
            activeService.printAllDeployed();
            community.printAllCriminalsCaptured();


        }

    }


//    public void publicPolicyReport(){
//        //Data for release to politicians.
//        System.out.println("=================SUMMARY FOR POLICY MAKERS=============================");
//        int totOps =0;
//        int totArrests =0;
//        int totRehabs =0;
//        for(Operation op:ops)
//        {
//            if (op instanceof Raid){
//                totArrests+=((Raid) op).countArrests();
//                totOps+=1;
//            }else if(op instanceof Zoso){
//                totArrests+=((Zoso) op).countArrests();
//                totOps+=1;
//            }if(op instanceof Soe){
//                totRehabs+=((Soe) op).getNumRehab();
//            }
//
//        }
//        String str = "We expect " + totOps +" operation(s), yielding " +totArrests + " arrest(s)";
//        if (totRehabs >0)
//            str+= " and "+ totRehabs +" rehab(s)";
//        str +=".";
//
//        System.out.println(str);
//        System.out.println("");
//
//
//
//        //LOGIC TO DISPLAY ARRESTED CRIMINALS AND THEIR COMMUNITIES
//        /*String str2 = "==========Arrested Criminals=========";
//        System.out.println(str2);
//        for(Community cm:communities)
//            for(int i=0;i<cm.getCriminals().size();i++)
//                System.out.println(cm.getCriminals().get(i)+" from the community "+ cm.getName());
//*/
//
//    }

//    public void classifiedInformationBrief(){
//        System.out.println("=================CLASSIFIED INTERNAL OPERATION BRIEF=============================");
//        //Security Officers Internal Brief
//        for(int i=0; i<ops.size(); i++)
//        {
//            Operation op = ops.get(i);
//            if (op instanceof Raid)
//                System.out.println((Raid) op);
//            else if (op instanceof UnderCover)
//                System.out.println((UnderCover) op);
//            else if (op instanceof Zoso )
//                if(op instanceof Soe)
//                    System.out.println((Soe)op);
//                else
//                    System.out.println((Zoso)op);
//
//
//        }
//    }



