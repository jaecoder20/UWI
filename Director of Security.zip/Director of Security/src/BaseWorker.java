import java.util.Base64;


public abstract class BaseWorker {
    private String name;
    private int age;
    private boolean publish; //indicates whether the worker wants their names to be published to public
    private boolean alive;
    public BaseWorker(){}//default constructor
    public BaseWorker(String name, int age, boolean publish){
        this.name=name;
        this.age=age;
        this.publish=publish;
        alive = true;
    }

    public int getAge(){return age;}
    public boolean getPublish(){return publish;}
    public String getName(){return name;}
    public String toString(){
        System.out.println(" ");//allows data to be output onto new line in file
        return getName()+" "+getAge()+" "+(getPublish()?1:0);
    }
    public void killed(){this.alive=false;}
    public boolean isAlive(){return alive;}



}
