import java.io.*;
import java.net.ServerSocket;
import java.nio.file.StandardOpenOption;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Scanner;
import java.time.*;

/**
 *
 * @author PGaynor
 */
public class EntryScreen
{

     //This program provides entry screens to accept workers and resources

    public EntryScreen()
    {
        /**
         * This is the default constructor, which is the only one needed.
         */
    }

    public Soldier getSoldier(Scanner scan)
    {
        //accepts information on a soldier
        Soldier s=null;
        scan.nextLine();
        Services services = Services.getService();
        try{
            System.out.println("Enter Name:");
            String name = scan.nextLine();
            System.out.println("Enter Age:");
            int age= Integer.parseInt(scan.nextLine());
            System.out.println("Willing to publish?(1=yes,0=no):");
            int willpub= Integer.parseInt(scan.nextLine());
            boolean pub;
            if (willpub==0)
                pub =false;
            else
                pub = true;
            s = new Soldier(name, age,pub);
            try{

            PrintStream outSoldiers = new PrintStream(new FileOutputStream(services.getSoldierInFile(),true));
            outSoldiers.println(s);
            }catch(IOException io){}
            System.out.println("Soldier "+name+" successfully added.");
            System.out.println(" ");
        }
        catch (NumberFormatException nfe)
        {
            System.out.println("Invalid input");
        }
        return s;

    }

    public SocialWorker getSocialWorker(Scanner scan)
    {
        /**
         * This method accepts information on a batch of vaccines
         */
        SocialWorker sW=null;
        scan.nextLine();
        Services services = Services.getService();

        try{
            System.out.println("Enter name: ");
            String name = scan.nextLine();
            System.out.println("Enter age: ");
            int age = Integer.parseInt(scan.nextLine());
            boolean pub=true;
            sW = new SocialWorker(name, age,pub);
            try{
                PrintStream outSocial = new PrintStream(new FileOutputStream(services.getSoldierInFile(),true));
                outSocial.println(sW);
            }catch(IOException io){}
            System.out.println("Social Worker "+name+" successfully added.");
            System.out.println("");

        }
        catch (NumberFormatException nfe)
        {
            System.out.println("Invalid input");
        }
        return sW;

    }


    public PoliceOfficer getOfficer(Scanner scan)
    {

         //This method accepts a police officer
        PoliceOfficer pO = null;
        Services services = Services.getService();
        try{
            System.out.println("Enter name: ");
            String name = scan.nextLine();
            System.out.println("Enter age: ");
            int age = Integer.parseInt(scan.nextLine());
            int willpub= Integer.parseInt(scan.nextLine());
            boolean pub;
            if (willpub==0)
                pub =false;
            else
                pub = true;
            pO = new PoliceOfficer(name, age,pub);
            try{
                PrintStream outOfficer = new PrintStream(new FileOutputStream(services.getSoldierInFile(),true));
                outOfficer.println(pO);
            }catch(IOException io){}
            System.out.println("Police Officer "+name+" successfully added.");
            System.out.println("");

        }
        catch (NumberFormatException nfe)
        {
            System.out.println("Invalid input");
        }
        return pO;
    }

    public Community getCommunity(Scanner scan){
        Community community = null;
        try{
            scan = new Scanner(System.in);
            System.out.println("Enter the name of the community");
            String name = scan.nextLine();
            System.out.println("Enter the latitude of the community");
            double lat = scan.nextDouble();
            System.out.println("Enter the longitude of the community");
            double longt = scan.nextDouble();
            community = new Community(name,lat,longt);
            scan.nextLine();
//            System.out.print("Now evaluating "+name+" to determine appropriate actions");
//            for(int i=0;i<3;i++) {
//                Thread.sleep(800);
//                System.out.print(".");
//            }
//            Thread.sleep(800);
//            System.out.println("");
//            System.out.println("");

        }catch(NumberFormatException nfe){}
        return community ;
    }



}



















































