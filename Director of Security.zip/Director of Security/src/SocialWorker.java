public class SocialWorker extends BaseWorker{
    public SocialWorker(String name, int age, boolean publish){
        super(name,age,true);//social workers will always have their names published
    }
    public String toString(){
        System.out.println(" ");//allows data to be output properly in file
        return getName()+" "+getAge();
    }

}
