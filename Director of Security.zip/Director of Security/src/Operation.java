import java.util.ArrayList;
public class Operation
{
    private String callSign;
    private static int opTracker=0;
    protected Community cm;
    private String opsName;

    public Operation(Community community)
    {
        cm = community;
        callSign = "DS"+opTracker++;
    }


    public String getCallSign()
    {
        return callSign;

    }

    public String getOpsName(){return opsName;}
    public void setOpsName(String name){opsName = name;}


}
